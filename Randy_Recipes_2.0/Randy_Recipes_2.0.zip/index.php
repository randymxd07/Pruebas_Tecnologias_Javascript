<?php $fondo = 'index' ?>
<?php $titulo = 'Pagina Principal' ?>

<?php include_once "partes/parte_head.php" ?>

    <div class="header mb-5" style="color: white; font-family: serif">
        <p class="text-center zoomIn animated" style="font-size: 60px; margin-top: 170px;">“Una receta no tiene alma.</p>
        <p class="text-center zoomIn animated" style="font-size: 60px;">Es el cocinero quien debe darle alma a la receta.”</p>
    </div>

<?php include_once "partes/parte_footer.php" ?>